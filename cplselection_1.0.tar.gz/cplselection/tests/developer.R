## This file is for developer only. Delete before publish.
library(devtools)
library(roxygen2)
library(usethis)
# frequently used commands
# while editing code
load_all()
# while editing tests
test()
check()
# while editing roxygen (generate NAMESPACE)
# place @export in roxygen comments
document()
?fun
# last steps
# git commit
# git push

