## ------------------------
# logPosteriorTheta <- function(theta,zs,zo)
# drawBeta <- function(y,x,sigma,zcond,theta,V0inv,V0invu0)
# logPosteriorBeta <- function(beta,y,x,zcond,theta,u0,V0inv,y_dist,morepar=NULL)
# computezCont <- function(y_dist,y,x,beta,zcond=NULL,theta=NULL,morepar=NULL)
# drawzDisc <- function(y_dist,y,x,beta,zcond,theta,morepar=NULL)
# 
## ------------------------

# logPosteriorBeta(propose,YS,XS,zo,theta[,i],u0S,V0invS,select_dist)